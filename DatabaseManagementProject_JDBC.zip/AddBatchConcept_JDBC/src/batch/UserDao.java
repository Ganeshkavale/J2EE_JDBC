package batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class UserDao {

	public void saveUser(List<User> list) throws ClassNotFoundException, SQLException{
		
		Connection cn = UserConnection.getUserConnection();
		
		
		String insert = "insert into user_batch values(?,?,?)";		
		
		PreparedStatement prep = cn.prepareStatement(insert);
		
		for(User user:list) {
			
			prep.setInt(1, user.getId());
			prep.setString(2, user.getName());
			
			prep.setLong(3, user.getMobileNo());
			
			prep.addBatch();		
			
		}
		
		prep.executeBatch();
		
		System.out.println("<====================== DATA STORED SUCCESSFULLY ========================>");
		
	}
}
