package batch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UserConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			getUserConnection();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Connection getUserConnection() throws SQLException, ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		String url = "jdbc:mysql://localhost:3306/batch_concept";
		
		String username = "root";
		
		String password = "Ganesh@123";
		
		Connection connection = DriverManager.getConnection(url, username, password);
		
		return connection;
	}
}
