package batch;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class UserControllerUsingLoop {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		UserDao userDao = new UserDao();
		
		
		Scanner sc = new Scanner(System.in);
		
		List<User> list = new ArrayList<User>();
		
		System.out.println("Enter a size: ");
		
		int size = sc.nextInt();
		
		for(int i = 1; i<=size ; i++) {
			
			User user = new User();
			
			System.out.println("Enter your id: ");
			
			user.setId(sc.nextInt());
			
			System.out.println("Enter your name: ");
			
			user.setName(sc.next());
			
			System.out.println("Enter your mobile number: ");
			
			user.setMobileNo(sc.nextLong());
					
			list.add(user);
			
		}
		
		userDao.saveUser(list);
		
		

	}

}
