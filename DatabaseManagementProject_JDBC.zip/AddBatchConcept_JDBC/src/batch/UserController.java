package batch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserController {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		User user1 = new User();
		
		User user2 = new User();
		
		User user3 = new User();
		
		User user4 = new User();
		
		
		user1.setId(1);
		
		user1.setName("Mr. Ganesh Kavale");
		
		user1.setMobileNo(9067609181L);
		
		
		user2.setId(2);
		
		user2.setName("Mr. Sunder Pichai");
		
		user2.setMobileNo(7028477727L);
		
		
		user3.setId(3);
		
		user3.setName("Mr. Satya Nadela");
		
		user3.setMobileNo(9766350820L);
		
		
		
		user4.setId(5);
		
		user4.setName("Mr. Elon Musk");
		
		user4.setMobileNo(9860038580L);
		
		List<User> list = new ArrayList<User>();
		
		list.add(user1);
		
		list.add(user2);
		
		list.add(user3);
		
		list.add(user4);	
		
		Connection cn = UserConnection.getUserConnection();
		
		PreparedStatement prep = null;
		
		String insert = "insert into user_batch values(?,?,?)";
		
		prep= cn.prepareStatement(insert);
		
		for(User user: list) {
			
			prep.setInt(1,user.getId());
			
			prep.setString(2,user.getName());
			
			prep.setLong(3,user.getMobileNo());
			
			prep.addBatch();
			
		}
		
		prep.executeBatch();
		
		System.out.println("<----------------- BATCH STORED ------------------->");
	}

}
