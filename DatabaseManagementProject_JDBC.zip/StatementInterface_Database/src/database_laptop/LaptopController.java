package database_laptop;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

public class LaptopController {
	
	static Scanner sc = new Scanner(System.in);
	
	static Laptop laptop = new Laptop();
	
	
	static LaptopDao laptopDao = new LaptopDao();

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		while(true) {
			
			
			System.out.println("\n\n<---------------------- LAPTOP DATABASE ----------------------->");
			
			System.out.println("1.Add Laptop Details \t 2.Update detailsById \t3.DeleteDetalsById \t4.DisplayDetails");
			
			switch(sc.nextInt()) {
			
				case 1:{
					
					System.out.println("Enter laptop id: ");
					
					int id = sc.nextInt();
					
					System.out.println("Enter laptop name: ");
					
					String name = sc.next();
					
					System.out.println("Enter laptop price: ");
					
					double price = sc.nextDouble();
					
					laptop.setId(id);
					
					laptop.setName(name);
					
					laptop.setPrice(price);
					
					if(laptop!=null) {
						
						System.out.println(laptop.getId());
						System.out.println(laptop.getName());
						System.out.println(laptop.getPrice());
						
						laptopDao.insertLaptop(laptop);
					}
					else {
						System.out.println("First enter details of the Laptop.........!");
					}				
										
				}break;
				
				case 2:{
					
					System.out.println("Enter id to update data: ");
					
					int id = sc.nextInt();
					
					laptop.setId(id);
					
					if(laptop != null) {
						laptopDao.updateLaptop(laptop);		
					}
					else {
						System.out.println("Enter details first!");
					}							
										
				}break;
				case 3:{
					
					System.out.println("Enter id to delete data: ");
					
					int id =sc.nextInt();
					
					laptop.setId(id);
					
					if(laptop != null) {
						laptopDao.updateLaptop(laptop);		
					}
					else {
						System.out.println("Enter details first!");
					}					
				}break;
				
				case 4:{
					
					laptopDao.displayLaptop(laptop);
				}break;
					
				
			}
		}

	}

}

