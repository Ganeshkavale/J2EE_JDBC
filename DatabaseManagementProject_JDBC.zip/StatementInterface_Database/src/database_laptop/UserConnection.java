package database_laptop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UserConnection {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		getUserConnection();

	}
	
	public static Connection getUserConnection() throws SQLException{
		
		String url = "jdbc:mysql://localhost:3306/database_user_prepare";
		
		String username = "root";
		
		String password = "Ganesh@123";
		
		Connection connection = DriverManager.getConnection(url,username,password);
		
		return connection;		
	}

}