package database_laptop;

import java.sql.Connection;
import java.sql.SQLException;

public class DeleteDataAtOnce {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Connection cn = UserConnection.getUserConnection();
		
		java.sql.Statement stat = cn.createStatement();
		
		String delete = "delete from user";
		
		stat.execute(delete);
		
		System.out.println("<=================  DATA DELETED SUCCESSFULLY  =================>");
		

	}

}
