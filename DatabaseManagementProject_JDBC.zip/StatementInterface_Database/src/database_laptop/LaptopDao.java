package database_laptop;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class LaptopDao {
	
	static Scanner sc = new Scanner(System.in);


	static Connection connection;
	public void insertLaptop(Laptop laptop) throws SQLException {
	
		connection = UserConnection.getUserConnection();
		
		try {
			java.sql.Statement statement = connection.createStatement();
			
			String insert = "insert into data_laptop values("+laptop.getId()+",'"+laptop.getName()+"', '"+laptop.getPrice()+"')";
			
			int check = statement.executeUpdate(insert);
			
			if(check !=0) {
				
				System.out.println("<--------------- DATA INSERTED SUCCESSFULLY ----------------->");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateLaptop(Laptop laptop) {
		
		try {
			
			connection = UserConnection.getUserConnection();
			
			java.sql.Statement statement = connection.createStatement();
			
			System.out.println("Enter name to Update: ");
			
			String update = "update data_laptop set name = '"+sc.next()+"' where id = "+laptop.getId()+"";
			
			int check = statement.executeUpdate(update);
			
			if(check != 0) {
				System.out.println("<--------------- DATA UPDATED SUCCESSFULLY --------------->");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public void deleteLaptop(Laptop laptop) {
		
		try {
			connection = UserConnection.getUserConnection();
			
			java.sql.Statement statement = connection.createStatement();
			
			String delete = "delete from data_laptop where id = "+laptop.getId()+"";
			
			int check = statement.executeUpdate(delete);
			
			if(check != 0) {
				System.out.println("<--------------- DATA DELETED SUCCESSFULLY --------------->");
			}else {
				System.out.println("<--------------- FIRST ENTER DETAILS ------------------>");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void displayLaptop(Laptop laptop) {
		
		try {
			connection = UserConnection.getUserConnection();
			
			java.sql.Statement statement = connection.createStatement();
			
			String display = "select * from data_laptop";
			
			ResultSet resultSet = statement.executeQuery(display);
			
			while(resultSet.next()) {
				
				System.out.println("id = " + resultSet.getInt(1));
				System.out.println("name = " + resultSet.getString(2));
				System.out.println("price = " + resultSet.getString(3));
				
				System.out.println("\n<========================================================>\n");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
