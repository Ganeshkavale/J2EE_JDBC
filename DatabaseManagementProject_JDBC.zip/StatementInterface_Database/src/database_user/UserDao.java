package database_user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UserDao {
	    public static Connection connection;
        String url="jdbc:mysql://localhost:3306/database_user";
        String username="root";
        String password="Ganesh@123";
        
        public User insertUser(User user) {
        	
        	try {
        		//JVM can call the driver implicitely..
        		
				connection=DriverManager.getConnection(url, username, password);
				Statement statement=connection.createStatement();
				String insert="insert into database_user.user values("+user.getId()+",'"+user.getName()+"','"+user.getEmail()+"','"+user.getMobileNo()+"')";
				int ip=statement.executeUpdate(insert);
				
				if(ip!=0) {
					System.out.println(">>>>>>Data inserted!<<<<<<<");
				}
			} catch (SQLException e) {
			    e.getMessage();
			    System.out.println("Check your SQL query!");
			}
        	return user;
        }
        
        public void updateUser(User user) {
        	
        	try	{
        		
        	Scanner m1=new Scanner(System.in);
        	System.out.println("enter updated name: ");
        	connection=DriverManager.getConnection(url, username, password);
			Statement statement=connection.createStatement();
			String update="update user set name='"+m1.next()+"' where id="+user.getId()+"";
			int ip=statement.executeUpdate(update);
			if(ip!=0) {
				System.out.println(">>>>>>>Data updated<<<<<<");
			}
        	}
        	catch (SQLException e) {
        		e.getMessage();
        		System.out.println("check SQL Query!");
			}
        }
        
        public void delete(User user) {
        	try {
				connection=DriverManager.getConnection(url, username, password);
				Statement statement=connection.createStatement();
				String delete="delete from user where id="+user.getId()+"";
				int ip=statement.executeUpdate(delete);
				if(ip!=0) {
					System.out.println(">>>>>>Data Deleted<<<<<<<");
				}
			} catch (SQLException e) {
			    e.getMessage();
			    System.out.println("Check your SQL query!");
			}
        }
        public void displayUser(User user) {
        	try {
				connection=DriverManager.getConnection(url, username, password);
				Statement statement=connection.createStatement();
				String display="select * from user";
				ResultSet resultset=statement.executeQuery(display);
				while(resultset.next()) {
					System.out.println("Id= "+resultset.getInt(1));
					System.out.println("Name= "+resultset.getString(2));
					System.out.println("Email= "+resultset.getString(3));
					System.out.println("Name= "+resultset.getLong(4));
					System.out.println("===================");
				}
				
			} catch (SQLException e) {
			    e.getMessage();
			    System.out.println("Check your SQL query!");
			}
        	
        	finally{
        		
        		try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
        		
        	}
        }
       
}


