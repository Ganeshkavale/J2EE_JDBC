package database_user;


import java.util.Scanner;

public class UserController {
	
      static User user = new User();
      static UserDao userDao = new UserDao();
      
      public static void main(String[] args) {
		Scanner m=new Scanner(System.in);
		
		while(true) {
			
			System.out.println("enter your choice!");
			System.out.println("1.Add user\t 2.update user\t 3.Delete user\t 4.Display user");
			
			int choice=m.nextInt();
			
			
			switch(choice) {
			case 1:{
				System.out.println("enter user id: ");
				int id=m.nextInt();
				
				System.out.println("enter user name: ");
				String name=m.next();
				
				System.out.println("enter user email: ");
				String email=m.next();
				
				System.out.println("enter user mobileNo: ");
				long mobileNo=m.nextLong();
				
			   user.setId(id);
			   user.setName(name);
			   user.setEmail(email);
			   user.setMobileNo(mobileNo);
			   
			   if(user!=null) {
				   
				   System.out.println(user.getId());
				   System.out.println(user.getName());
				   System.out.println(user.getEmail());
				   System.out.println(user.getMobileNo());
				   
				   userDao.insertUser(user);
			   }
			   else {
				   System.out.println("First set the user details!");
			   }
			   break;
			}
			
			case 2:{
				
				System.out.println("enter user id: ");
				
				int id=m.nextInt();
				
				user.setId(id);
				
				if(user!=null) {
					userDao.updateUser(user);
				}
				 else {
					   System.out.println("First set the user details!");
				}
				 break;
			}
			case 3:{
				
				System.out.println("enter user id: ");
				int id=m.nextInt();
				user.setId(id);
				if(user!=null) {
					userDao.delete(user);
				}
				 else {
					   System.out.println("First set the user details!");
		        }
				 break;
			}
			case 4:{
				if(user!=null) {
					userDao.displayUser(user);
				}
				 else {
					   System.out.println("First set the user details!");
			   }
				 break;
			}
		}
	}
	   
	}
}

