package database_user;

public class User {

	private int id;
	
	private String name;
	
	private String email;
	
	private long mobileNo;
	
	//bean class or pojo class or entity class
	
	//bean class : WHere we write the private members and the getter and setter methods 	

	//pojo class : WHere we write the private members and the getter and setter methods and other useful methods
	
	public User(int id, String name, String email, long mobileNo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.mobileNo = mobileNo;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", email=" + email + ", mobileNo=" + mobileNo + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	

}
