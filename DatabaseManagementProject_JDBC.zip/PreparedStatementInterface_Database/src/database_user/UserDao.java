package database_user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao<PrepareStatement> {
	
	static Connection connection;
	
	public void userSave(User user) {
			
	//	we are preparing the statement for 
		
	//	The prepare statement is a interface which is present in java.sql package.
		
	//	If we want to take the dynamic data to insert into the database as a place holder(?)
		
	//	Then we will go for prepare statement.
		
	//	Inside prepare statement there are n number of methods.
		
	//	if persisting of integer value we will go for setInt() method of prepare statement.
		//prepareStatement.setInt(placeholder_Position, passing value);

	// For persisting String value we will use: setString()
		//	prepareStatement.setString(placeholder_Position, passing value);
	
	try {
		//making connection
		//step-1
		connection = UserConnection.getUserConnection();	

		//step-2
			
		String insert = "insert into user values(?,?,?,?)";
		
		
		//step-3
		
		PreparedStatement prepareStatement;
		
		prepareStatement = connection.prepareStatement(insert);		
		
		prepareStatement.setInt(1,user.getID());
		
		prepareStatement.setString(2,user.getName());
		
		prepareStatement.setString(3,user.getEmail());
		
		prepareStatement.setLong(4,user.getMobileNo());
		
		
		prepareStatement.execute();
		
		System.out.println("<------------  DATA STORED ------------->");
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
	}
	 public void userUpdate(User user, int id) throws ClassNotFoundException, SQLException {
     	
     	connection = UserConnection.getUserConnection();
     	
     	String update = "update user set name = Rahul where id = ?";
     	
     	PreparedStatement prepareStatement;
		
		prepareStatement = connection.prepareStatement(update);	
     	
     	prepareStatement.setString(1,user.getName());
     	
     	prepareStatement.setInt(2,user.getID());
     	
     	prepareStatement.execute();
     	
     	System.out.println("<------------  DATA UPDATED ------------->");
     }
	 public void deleteUser(String email) throws ClassNotFoundException, SQLException {
	     	
	     	connection = UserConnection.getUserConnection();
	     	
	     	String delete = "delete from user where email = ?";	//    ? this symbol is called as Parameter marker.
	     	
	     	PreparedStatement prepareStatement;
			
			prepareStatement = connection.prepareStatement(delete);	
	     		     	
	     	prepareStatement.setString(1,email);
	     	
	     	prepareStatement.execute();
	     	
	     	System.out.println("<------------  DATA DELETED ------------->");
	     }
	 
	 public void displayUser() throws ClassNotFoundException, SQLException {
	     	
	     	connection = UserConnection.getUserConnection();
	     	
	     	String display = "select * from user";
	     	
	     	PreparedStatement prepareStatement;
			
			prepareStatement = connection.prepareStatement(display);	
	     		     	
	       	ResultSet resultSet = prepareStatement.executeQuery();
	       	
	       	System.out.println("\t\t"+ "id" + "\t\t" + "Name" + "\t\t"+ "Email" + "\t\t"+ "MobileNo");
	       	
	       	while(resultSet.next()) {
	       		
	       		System.out.print("\t\t"+resultSet.getInt(1));
	       		
	       		System.out.print("\t\t"+resultSet.getString(2));
	       		
	       		System.out.print("\t\t"+resultSet.getString(3));
	       		
	       		System.out.print("\t\t"+resultSet.getLong(4));
	       	}
	     	
	     	System.out.println("\n\n\n\t\t<------------  DATA DELETED ------------->");
	     }
     

}












