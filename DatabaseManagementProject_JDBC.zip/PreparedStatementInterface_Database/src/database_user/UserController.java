package database_user;

import java.sql.SQLException;
import java.util.*;

public class UserController {
	
	static User user;
	
	static UserDao dao;

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			
			System.out.println("Entered into the user database: ");
			
			System.out.println("1.saveUser \n2.updateUser \n3.deleteUser \n4.displayUser");
			
			System.out.println("Enter your choice: ");
			
			switch(sc.nextInt()) {
			
				case 1:{
					
					user = new User();
					
					dao = new UserDao();
					
					System.out.println("Enter your id: ");
					
					int id = sc.nextInt();
					
					System.out.println("Enter your name: ");
					
					String name = sc.next();
										
					System.out.println("Enter your email: ");
					
					String email = sc.next();
														
					System.out.println("Enter your mobileno: ");
					
					long mn = sc.nextLong();
					
					user.setID(id);
					
					user.setName(name);
					
					user.setEmail(email);
					
					user.setMobileNo(mn);	
					
					dao.userSave(user);
				
				}break;
				
				case 2:{
					
					user = new User();
					
					dao = new UserDao();
					
					System.out.println("Enter your id: ");
					
					int id = sc.nextInt();
										
					user.setID(id);
										
					dao.userUpdate(user,id);				
					
				}break;
				
				case 3:{
										
					dao = new UserDao();
					
					System.out.println("Enter email: ");
					
					String name = sc.next();
										
					dao.deleteUser(name);				
					
				}break;
				case 4:{
					
					dao = new UserDao();
					
					dao.displayUser();
				}break;
			}
			
		}		

		
	}

}
