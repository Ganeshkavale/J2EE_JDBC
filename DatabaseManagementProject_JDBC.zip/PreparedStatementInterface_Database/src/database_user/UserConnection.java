package database_user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class UserConnection {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		
		getUserConnection();

	}
	
	public static Connection getUserConnection() throws ClassNotFoundException {
		
		Class.forName("com.mysql.cj.jdbc.Driver"); //cj deprecated
		
		String url ="jdbc:mysql://localhost:3306/database_user_prepare";
		
		String pass ="Ganesh@123";
		String user ="root";

		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
}

